# -*- coding: utf-8 -*-

from hydpy.models.hstream_v1 import *

simulationstep("1h")
parameterstep("1d")

lag(0.0)
damp(0.0)
